package com.mycompany.domain;

public class Product {

    String ProductID;
    String ProductName;
    int ProductPrice;

    public Product(){

    }

    public Product(String productid, String productName, int productPrice) 
    {
        this.ProductID = productid;
        this.ProductName = productName;
        this.ProductPrice = productPrice;
    }



    public String getProductid() {
        return ProductID;
    }

    public void setProductid(String productid) {
        this.ProductID = productid;
    }

    public String getProductName() {
        return ProductName;
    }

    public void setProductName(String productName) {
        this.ProductName = productName;
    }

    public int getProductPrice() {
        return ProductPrice;
    }

    public void setProductPrice(int productPrice) {
        this.ProductPrice = productPrice;
    }

    @Override
    public String toString(){
        return "Product [ProductID=" + ProductID + ", productName=" + ProductName + ", productPrice=" + ProductPrice + "]";
    }

}