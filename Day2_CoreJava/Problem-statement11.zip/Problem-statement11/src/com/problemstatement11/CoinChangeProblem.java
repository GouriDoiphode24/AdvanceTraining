package com.problemstatement11;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class CoinChangeProblem {
	
	static int deno[] = {1,2,5,10,20,50,100,500,2000};
	static int n = deno.length;

	static void findMin(int V)
	{
		
		List<Integer> ans = new ArrayList();

		
		for (int i = n - 1; i >= 0; i--)
		{
			while (V >= deno[i])
			{
				V -= deno[i];
				ans.add(deno[i]);
			}
		}
		int j;
		for (int i = 0; i < ans.size(); i++)
		{
			
			System.out.print(" " + ans.get(i)+" * "+Collections.frequency(ans, ans.get(i))+" ");
			j=i;
			while(j<ans.size()-1) {
				if(ans.get(j)==ans.get(j+1)) {
					j++;
					continue;	
				}
				else {
					break;
				}	
			}
			i=j;
			if(i<ans.size()-1) {
				System.out.print("+");
			}
		}
		
	}

	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the number : ");
		int n = sc.nextInt();
		System.out.println("BREAKDOWN : ");
		findMin(n);
	}
}

