package com.problemstatement1;

public class Rectangle 
{
	double length;
	double breath;
	
	public Rectangle() {
		
	}

	public Rectangle(double length, double breath) 
	{
		this.length = length;
		this.breath = breath;
	}

	public void area()
	{
		double area;
		area=length *breath;
		displayInformation(area);		 
	}
	
	public void displayInformation(double area)
	{
		System.out.println("length of Rectangle:"+ length);
		System.out.println("Breath of Rectangle:"+ breath);
		System.out.println("Area of Rectangle:"+ area);
	}
	
}