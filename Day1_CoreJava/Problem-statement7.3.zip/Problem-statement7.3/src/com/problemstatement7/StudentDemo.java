package com.problemstatement7;

import java.io.*;

import java.util.Scanner;


public class StudentDemo
{
	public static void display(File file1) throws IOException
	{
		
		FileReader reader= new FileReader(file1);
		int data;
		while((data=reader.read())!=-1)
		{
			System.out.print((char)data);
		}
	}
		
     public static void main(String args[])throws Exception
     {
          BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
          Scanner sc = new Scanner(System.in);
          System.out.print("Enter roll number: ");
          int roll = Integer.parseInt(br.readLine());
          System.out.print("\nEnter name: ");
          String name = br.readLine();
          System.out.print("\nEnter age: ");
          int age = Integer.parseInt(br.readLine());
          System.out.print("\nEnter Address: ");
          String Address = br.readLine();
          Student s = new Student(roll,name,age,Address);
         StudentDemo s2= new StudentDemo();
      		File file=new File("D:\\file\\kumar.txt");
      		System.out.println("want to write into file : 'yes' or 'no' ");
      		String str=sc.next();
      		
			if(file.createNewFile() && str=="yes")
      		{
      			System.out.println("File is created");
      		}
      		else
      		{
      			System.out.println("File is updated successfully");
      		}
      		
      		FileWriter writer= new FileWriter(file, false);
      		writer.write(Integer.toString(s.roll));
      		writer.write(s.name);
      		writer.write(Integer.toString(s.age));
      		writer.write(s.Address);
      		writer.close();
      		s2.display(file);
      	}
     }


