package com.problemstatement6;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Student 
{

	public static void  main(String[] args) 
	{
		ArrayList<String> al = new ArrayList<String> ();
		int n;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of Students : ");
		n=sc.nextInt();
		System.out.println("Enter the Student Names : ");
		
		for(int i=0; i<n; i++)
		{
			al.add(sc.next());
		}
		
		System.out.println("Students List :");

		for(String a:al)
		{
			System.out.println(a);
		}

		System.out.println("Enter the name of Student to be Searched : ");
		String st = sc.next();
		
		int position = Collections.binarySearch(al,st);
		System.out.println("Position of " + st + " is : " + position);
		
	}
	
}