package com.problemstatement3;

public interface MedicineInfo 
{
	public default void displayLabel()
	{
		System.out.println("Company : Globel Pharma");
		System.out.println("Address : Pune");
	}
	
	class Tablet implements MedicineInfo
	{
	public void displayLabel()
	{
	System.out.println("store in a cool dry place");
	}
	}
	
	class Syrup implements MedicineInfo
	{
	public void displayLabel()
	{
	System.out.println("Consumption as directed by the physician");
	}
	}
	
	class Ointment implements MedicineInfo
	{
	public void displayLabel()
	{
	System.out.println("for external use only");
	}
	}

}
