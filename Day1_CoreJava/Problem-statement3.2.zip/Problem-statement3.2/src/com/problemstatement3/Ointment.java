package com.problemstatement3;

public class Ointment implements MedicineInfo {

}
