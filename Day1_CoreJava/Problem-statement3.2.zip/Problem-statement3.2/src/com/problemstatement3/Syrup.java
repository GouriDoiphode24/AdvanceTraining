package com.problemstatement3;

public class Syrup implements MedicineInfo {

}
