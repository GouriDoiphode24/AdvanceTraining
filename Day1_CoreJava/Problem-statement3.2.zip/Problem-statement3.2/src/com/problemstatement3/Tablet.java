package com.problemstatement3;

public class Tablet implements MedicineInfo {

}
